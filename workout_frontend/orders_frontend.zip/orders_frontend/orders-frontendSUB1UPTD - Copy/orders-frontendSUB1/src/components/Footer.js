function Footer(){
    return(

        <footer>
            <h3>Welcome to the footer </h3>
        </footer>

    );
}


export default Footer;