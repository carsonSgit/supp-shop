import Main from "../components/Main";



function Orders(){
    return(

        <div>
            <h1>welcome to the orders main page</h1>
            <Main/>
        </div>
    )
}


export default Orders;