import { UpdateOrder } from "components/UpdateOrder";


function GetAll() {
  


    return( <div>
        <p>this is the list of all orders placed</p>
       
            
            <UpdateOrder/>
            
    </div>);
}

export default GetAll;