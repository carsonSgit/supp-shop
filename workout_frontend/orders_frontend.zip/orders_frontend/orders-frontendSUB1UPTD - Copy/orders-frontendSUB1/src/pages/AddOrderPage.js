import { AddOrder } from "components/AddOrder";


function AddOrderPage(){


    return(

        <div>
            <h1>welcome, would you like to add an order</h1>
            <AddOrder/>
        </div>
    )
}

export default AddOrderPage;